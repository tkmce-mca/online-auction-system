﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_Reg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Connect c = new Connect();
        String  r = c.save("insert into register values('" + TextBox1.Text + "','" + TextBox2.Text + "' ,'" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')");
        string x = c.save("insert into login values('"+TextBox4.Text+"','"+TextBox6.Text+"','user')");
        if(r=="1" && x=="1")
            {
            Label1.Text = "sucscscsccs";

        }
        else
        {
            Label1.Text = r;
        }
    }
}