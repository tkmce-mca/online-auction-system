﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for Connect
/// </summary>
public class Connect
{
    SqlConnection con;
    SqlCommand cd;
    public SqlDataReader dr;
    SqlDataAdapter rd;
    public void getcon()
    {
        try {


            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\mydb.mdf;Integrated Security=True");
            con.Open();
        }
        catch (Exception Ex)
        { }
    }

    public string save(String q)
    {
        try {

            getcon();
            cd = new SqlCommand(q, con);
            int y= cd.ExecuteNonQuery();
            con.Close();
            return y+"";
        }
        catch(Exception Ex) {
            return Ex.Message;
        }
    }
}